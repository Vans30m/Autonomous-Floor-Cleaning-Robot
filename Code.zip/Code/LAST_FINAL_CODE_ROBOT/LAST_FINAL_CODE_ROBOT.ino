#include <SoftwareSerial.h>

// --- BLUETOOTH COMMAND DEFINITIONS ---
#define FORWARD 'F'
#define BACKWARD 'B'
#define LEFT 'L'
#define RIGHT 'R'
#define PAUSE 'P'
#define CIRCLE 'C'
#define CROSS 'X'
#define TRIANGLE 'T'
#define SQUARE 'S'

SoftwareSerial bluetooth(10, 11); // RX on 10, TX on 11
bool autoMode = false;     // Flag for autonomous mode
bool isMoving = false;     // Tracks if motors are currently running

// --- MOVEMENT PINS (L298N) ---
#define ENA_PIN 6   // PWM pin for Right Motor Speed
#define ENB_PIN 9   // PWM pin for Left Motor Speed
#define IN1_PIN 7   // Right Motor Forward
#define IN2_PIN 8   // Right Motor Backward
#define IN3_PIN 12  // Left Motor Forward 
#define IN4_PIN 13  // Left Motor Backward 

int currentSpeed = 128; // Default speed starts at 50% (128)

// Hold-to-Move Timeout Variables
unsigned long lastMoveTime = 0; 
const int timeoutDelay = 250; // Milliseconds before auto-stopping

// --- MOP VARIABLES ---
#define MOP_MOTOR_PIN 5     // PWM pin for mop motor speed control
int mopSpeed = 0;           // Store mop motor speed (0-255)

int lastTurn = 0; // Memory variable to prevent wiggling (-1 = Left, 1 = Right)

// =============================================
// SETUP FUNCTION
// =============================================
void setup() {
  Serial.begin(9600);
  bluetooth.begin(9600);

  // Configure Movement Pins
  pinMode(ENA_PIN, OUTPUT); 
  pinMode(ENB_PIN, OUTPUT); 
  pinMode(IN1_PIN, OUTPUT); 
  pinMode(IN2_PIN, OUTPUT); 
  pinMode(IN3_PIN, OUTPUT); 
  pinMode(IN4_PIN, OUTPUT);

  // Configure Mop Pin
  pinMode(MOP_MOTOR_PIN, OUTPUT);

  // Configure Ultrasonic Pins
  pinMode(2, INPUT);    // ECHO Left Sensor
  pinMode(3, INPUT);    // ECHO Center Sensor
  pinMode(4, INPUT);    // ECHO Right Sensor
  pinMode(A0, OUTPUT);  // TRIG Left Sensor
  pinMode(A1, OUTPUT);  // TRIG Center Sensor
  pinMode(A2, OUTPUT);  // TRIG Right Sensor

  stopMotors();
  analogWrite(MOP_MOTOR_PIN, 0);
  
  Serial.println("=================================");
  Serial.println("Floor Cleaning Robot Ready!");
  Serial.println("=================================");
}

// =============================================
// MAIN LOOP FUNCTION
// =============================================
void loop() {
  // 1. Read Bluetooth Commands
  while (bluetooth.available() > 0) {
    char btCommand = bluetooth.read();
    executeCommand(btCommand);
  }

  // 2. Read Serial Commands
  while (Serial.available() > 0) {
    char serialCmd = Serial.read();
    if (serialCmd != '\n' && serialCmd != '\r') {
      executeCommand(serialCmd);
    }
  }

  // 3. Autonomous Mode Logic
  if (autoMode) {
    autonomousMode();
  }

  // 4. Hold-To-Move Timeout Logic
  if (!autoMode && isMoving && (millis() - lastMoveTime > timeoutDelay)) {
    stopMotors();
    isMoving = false;
  }

  // 5. Keep Mop Running
  analogWrite(MOP_MOTOR_PIN, mopSpeed);
  
  delay(20);
}

// =============================================
// MODE SWITCHING HELPER FUNCTION
// =============================================
void setAutoMode(bool state) {
  if (state == autoMode) return; 

  autoMode = state;
  
  if (autoMode) {
    delay(50); 
    Serial.println("Auto Mode ON");
  } else {
    Serial.println("Manual Mode");
  }
}

// =============================================
// COMMAND HANDLER
// =============================================
void executeCommand(char command) {
  switch (command) {
    
    // --- MOVEMENT CONTROLS ---
    case FORWARD:
      setAutoMode(false); 
      moveForward();
      lastMoveTime = millis(); 
      isMoving = true;
      break;
      
    case BACKWARD:
      setAutoMode(false);
      moveBackward();
      lastMoveTime = millis();
      isMoving = true;
      break;
      
    case LEFT:
      setAutoMode(false);
      turnLeft();
      lastMoveTime = millis();
      isMoving = true;
      break;

    case RIGHT: 
      setAutoMode(false);
      turnRight();
      lastMoveTime = millis();
      isMoving = true;
      break;

    // --- DRIVING SPEED CONTROLS ---
    case SQUARE:
      currentSpeed = 64; // 25%
      Serial.println("Driving Speed: 25%");
      break;

    case TRIANGLE:
      currentSpeed = 128; // 50%
      Serial.println("Driving Speed: 50%");
      break;

    case CIRCLE:
      currentSpeed = 192; // 75%
      Serial.println("Driving Speed: 75%");
      break;
      
    case CROSS:
      currentSpeed = 255; // 100%
      Serial.println("Driving Speed: 100%");
      break;

    // --- MODE CONTROLS ---
    case PAUSE: 
      setAutoMode(false);
      stopMotors();
      isMoving = false;
      break;

    case 'A': 
      setAutoMode(true); 
      break;

    case 'M': 
      setAutoMode(false);
      stopMotors();
      isMoving = false;
      break;

    // --- MOP CONTROLS ---
    case 'G':
      mopSpeed = 0;
      Serial.println("Mop: OFF");
      break;
      
    case 'H':
      mopSpeed = 64;
      Serial.println("Mop: 25%");
      break;
      
    case 'I':
      mopSpeed = 128;
      Serial.println("Mop: 50%");
      break;
      
    case 'J':
      mopSpeed = 192;
      Serial.println("Mop: 75%");
      break;
      
    case 'K':
      mopSpeed = 255;
      Serial.println("Mop: 100%");
      break;

    default:
      break;
  }
}

// =============================================
// ULTRASONIC SENSOR DISTANCE MEASUREMENT
// =============================================
long getDistance(int trigPin, int echoPin) {
  if (!autoMode) return 999; 

  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  long duration = pulseIn(echoPin, HIGH, 30000);
  if (duration == 0) return 999;
  
  long distance = duration * 0.034 / 2;
  if (distance > 400) return 999;
  
  return distance;
}

// =============================================
// AUTONOMOUS MODE
// =============================================
void autonomousMode() {
  long leftDist   = getDistance(A0, 2);
  long centerDist = getDistance(A1, 3);
  long rightDist  = getDistance(A2, 4);

  bool centerBlocked = (centerDist < 20);
  bool leftBlocked   = (leftDist < 15);
  bool rightBlocked  = (rightDist < 15);

  // --- TUNING VARIABLES FOR DODGING ---
  int turnTime = 150;        // Quick spin to brush past side obstacles
  int cornerTurnTime = 400;  // Longer 90-degree turn for facing a wall
  int escapeTurnTime = 800;  // Massive 180-degree turn to escape a trap
  
  int stopTime = 250;        // Resting time to prevent motor voltage spikes
  int reverseTime = 600;     // Time spent backing out of a corner
  int clearanceTime = 200;   // A short burst forward to clear an obstacle

  // ⭐ 1. FULL BLOCKED CASE (Trapped in a dead end)
  if (centerBlocked && leftBlocked && rightBlocked) {
    stopMotors(); delay(stopTime);
    moveBackward(); delay(reverseTime);
    stopMotors(); delay(stopTime);

    // Make a massive 180-degree spin based on memory
    if (lastTurn == 1) {
      turnRight(); delay(escapeTurnTime); 
    } else {
      turnLeft(); delay(escapeTurnTime); 
      lastTurn = -1; // Default to left if no memory exists
    }

    stopMotors(); delay(stopTime);
    return;
  }

  // ⭐ 2. FORWARD BLOCKED (Approaching a wall or corner straight on)
  if (centerBlocked) {
    stopMotors(); delay(stopTime);

    // MEMORY CHECK: Don't wiggle! If we recently turned left, keep turning left.
    if (lastTurn == -1) {
        turnLeft(); delay(cornerTurnTime);
    } 
    else if (lastTurn == 1) {
        turnRight(); delay(cornerTurnTime);
    } 
    // If no memory, pick the best open direction
    else {
        if (leftDist > rightDist) {
          turnLeft(); delay(cornerTurnTime); 
          lastTurn = -1;
        } else {
          turnRight(); delay(cornerTurnTime);
          lastTurn = 1;
        }
    }

    stopMotors(); delay(stopTime);
    return;
  }

  // ⭐ 3. ONLY LEFT BLOCKED → Dodge Right
  if (leftBlocked) {
    turnRight(); delay(turnTime);
    moveForward(); delay(clearanceTime); // Push past the obstacle
    lastTurn = 1;
    return;
  }

  // ⭐ 4. ONLY RIGHT BLOCKED → Dodge Left
  if (rightBlocked) {
    turnLeft(); delay(turnTime);
    moveForward(); delay(clearanceTime); // Push past the obstacle
    lastTurn = -1;
    return;
  }

  // ⭐ 5. PATH CLEAR → Drive Forward
  moveForward();
  lastTurn = 0; // Reset memory because we are driving straight safely
}

// =============================================
// MOVEMENT MOTOR FUNCTIONS
// =============================================
void moveForward() {
  analogWrite(ENA_PIN, currentSpeed); 
  analogWrite(ENB_PIN, currentSpeed); 
  digitalWrite(IN1_PIN, HIGH);        
  digitalWrite(IN2_PIN, LOW);         
  digitalWrite(IN3_PIN, HIGH);        
  digitalWrite(IN4_PIN, LOW);         
}

void moveBackward() {
  analogWrite(ENA_PIN, currentSpeed); 
  analogWrite(ENB_PIN, currentSpeed); 
  digitalWrite(IN1_PIN, LOW);         
  digitalWrite(IN2_PIN, HIGH);        
  digitalWrite(IN3_PIN, LOW);         
  digitalWrite(IN4_PIN, HIGH);        
}

void turnLeft() {
  analogWrite(ENA_PIN, currentSpeed); 
  analogWrite(ENB_PIN, currentSpeed); 
  digitalWrite(IN1_PIN, HIGH);        
  digitalWrite(IN2_PIN, LOW);         
  digitalWrite(IN3_PIN, LOW);         
  digitalWrite(IN4_PIN, HIGH);        
}

void turnRight() {
  analogWrite(ENA_PIN, currentSpeed); 
  analogWrite(ENB_PIN, currentSpeed); 
  digitalWrite(IN1_PIN, LOW);         
  digitalWrite(IN2_PIN, HIGH);        
  digitalWrite(IN3_PIN, HIGH);        
  digitalWrite(IN4_PIN, LOW);         
}

void stopMotors() {
  analogWrite(ENA_PIN, 0);            
  analogWrite(ENB_PIN, 0);            
  digitalWrite(IN1_PIN, LOW);         
  digitalWrite(IN2_PIN, LOW);         
  digitalWrite(IN3_PIN, LOW);         
  digitalWrite(IN4_PIN, LOW);         
}